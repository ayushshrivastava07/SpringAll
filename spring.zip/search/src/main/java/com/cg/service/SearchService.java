package com.cg.service;

import com.cg.bean.Search;
import com.cg.bean.SearchTwo;

public interface SearchService {

	
	public Search searchTrainee(int id);
	
	public SearchTwo searchTraineeTwo(int id);
}
