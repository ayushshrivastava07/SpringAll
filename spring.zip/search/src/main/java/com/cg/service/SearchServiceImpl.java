package com.cg.service;

import com.cg.bean.Search;
import com.cg.bean.SearchTwo;
import com.cg.dao.SearchDao;


public class SearchServiceImpl implements SearchService {

	SearchDao searchdao;
	@Override
	public Search searchTrainee(int id) {
		if (id == 0) {
			return null;
		}
		Search s = searchdao.search(id);
		return s;
		
	}

	@Override
	public SearchTwo searchTraineeTwo(int id) {
		if (id == 0) {
			return null;
		}
		SearchTwo s2 = searchdao.searchtwo(id);
		return s2;
		

	}

	public SearchDao getSearchdao() {
		return searchdao;
	}

	public void setSearchdao(SearchDao searchdao) {
		this.searchdao = searchdao;
	}

}
