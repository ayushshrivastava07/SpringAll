package com.cg.bean;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class SearchTwo {

	@Id
	private int traineeId2;
	
	private String traineeName2;
	
	private String traineeDomain2;
	
	private String traineeLocation2;

	public int getTraineeId2() {
		return traineeId2;
	}

	public void setTraineeId2(int traineeId2) {
		this.traineeId2 = traineeId2;
	}

	public String getTraineeName2() {
		return traineeName2;
	}

	public void setTraineeName2(String traineeName2) {
		this.traineeName2 = traineeName2;
	}

	public String getTraineeDomain2() {
		return traineeDomain2;
	}

	public void setTraineeDomain2(String traineeDomain2) {
		this.traineeDomain2 = traineeDomain2;
	}

	public String getTraineeLocation2() {
		return traineeLocation2;
	}

	public void setTraineeLocation2(String traineeLocation2) {
		this.traineeLocation2 = traineeLocation2;
	}

	@Override
	public String toString() {
		return "SearchTwo [traineeId2=" + traineeId2 + ", traineeName2=" + traineeName2 + ", traineeDomain2="
				+ traineeDomain2 + ", traineeLocation2=" + traineeLocation2 + "]";
	}


}
