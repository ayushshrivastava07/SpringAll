package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.bean.Search;
import com.cg.bean.SearchTwo;
import com.cg.service.SearchServiceImpl;


@Controller
public class SearchController {

	@Autowired
    SearchServiceImpl searchservice;

	
	@RequestMapping(method = RequestMethod.GET, path = "/authenticate")
	public String checkRetrieveRegister(Search search, Model model) {
		model.addAttribute("Search", search);
		return "authenticate";
	}
	
	@Transactional
	@RequestMapping(method = RequestMethod.POST, path = "/search")
	public ModelAndView searchEmployee(@ModelAttribute @Valid Search t) {

		ModelAndView mv = new ModelAndView();

		Search success = searchservice.searchTrainee(t.getTraineeId());
		List<Search> list = new ArrayList<Search>();
		list.add(success);
		mv.addObject("tlist", list);
		mv.addObject("trainee", new Search());
		mv.addObject("key", success);
		mv.setViewName("searchinfo");
		return mv;
	}
	@Transactional
	@RequestMapping(method = RequestMethod.POST, path = "/search2")
	public ModelAndView searchEmployee2(@ModelAttribute @Valid Search t) {

		ModelAndView mv = new ModelAndView();

		Search success = searchservice.searchTrainee(t.getTraineeId());
		List<Search> list = new ArrayList<Search>();
		list.add(success);
		mv.addObject("tlist", list);
		mv.addObject("trainee", new Search());
		mv.addObject("key", success);
		mv.setViewName("searchinfo");
		return mv;
	}
	@Transactional
	@RequestMapping(method = RequestMethod.GET, path = "/ref/{id}")
	public ModelAndView searchEmployeeNew(@PathVariable("id")int id) {

		ModelAndView mv = new ModelAndView();

		Search success = searchservice.searchTrainee(id);
		List<Search> list = new ArrayList<Search>();
		list.add(success);
		mv.addObject("id", success.getTraineeId());
		mv.addObject("name", success.getTraineeName());
		mv.addObject("location", success.getTraineeLocation());
		mv.addObject("domain", success.getTraineeDomain());
		mv.setViewName("showdetails");
		return mv;
	}
	

//	@Transactional
//	@RequestMapping(method = RequestMethod.POST, path = "/search")
//	public ModelAndView searchEmployeeUpdate(@ModelAttribute @Valid SearchTwo t2) {
//		ModelAndView mv = new ModelAndView();
//		SearchTwo success2 = searchservice.searchTraineeTwo(t2.getTraineeId2());
//		mv.addObject("id", success2.getTraineeId2());
//		mv.addObject("name", success2.getTraineeName2());
//		mv.addObject("location", success2.getTraineeLocation2());
//		mv.addObject("domain", success2.getTraineeDomain2());
//		mv.setViewName("showdetails");
//		return mv;
//	}
	}
