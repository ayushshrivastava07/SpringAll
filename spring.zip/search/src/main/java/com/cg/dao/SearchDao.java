package com.cg.dao;

import com.cg.bean.Search;
import com.cg.bean.SearchTwo;

public interface SearchDao {

	public Search search(int id);
	
	public SearchTwo searchtwo(int id);
}
