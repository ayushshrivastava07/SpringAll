package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.cg.bean.Search;
import com.cg.bean.SearchTwo;



public class SearchDaoImpl implements SearchDao{

	@PersistenceContext
	EntityManager em;
	@Override
	public Search search(int id) {
		Search t = em.find(Search.class, id);
		return t;
	}

	@Override
	public SearchTwo searchtwo(int id) {
		SearchTwo t2 = em.find(SearchTwo.class, id);
		return null;
	}

}
