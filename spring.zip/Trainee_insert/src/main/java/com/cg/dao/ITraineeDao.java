package com.cg.dao;

import java.util.List;

import com.cg.bean.Trainee;

public interface ITraineeDao {

	public void save(Trainee t);
	
//	public Trainee search(int id);
//
//	public List<Trainee> getAll();

}
