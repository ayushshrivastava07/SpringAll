package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.bean.Trainee;
import com.cg.service.TraineeServiceImpl;

@Controller
public class TraineeController {

	@Autowired
	TraineeServiceImpl traineeService;

	// LOGIN PAGE
	@RequestMapping(method = RequestMethod.GET, path = "/getPage")
	public String loginPage(@ModelAttribute("t") @Valid Trainee t) {
		ModelAndView mv = new ModelAndView();
		ArrayList<String> al=new ArrayList<>();
		al.add("India");
		al.add("England");
		al.add("Australia");
		al.add("Canada");
		mv.addObject("list",al);
		mv.setViewName("Hello");
		return "login";
	}

	// WELCOME PAGE WITH ALL OPERATIONS
	@RequestMapping(method = RequestMethod.POST, path = "/authenticate")
	public String operationPage(@ModelAttribute("t") @Valid Trainee t) {
		
			return "authenticate";
				
	}

	// ADD NEW RECORD PAGE

	@RequestMapping(method = RequestMethod.GET, path = "/add")
	public String display(@ModelAttribute("t") @Valid Trainee t) {
ModelAndView mv = new ModelAndView();
		
		ArrayList<String> al=new ArrayList<>();
		al.add("India");
		al.add("England");
		al.add("Australia");
		al.add("Canada");
		mv.addObject("list",al);
		mv.setViewName("Hello");

		return "addRecordForm";
	}

	@RequestMapping(method = RequestMethod.POST, path = "/recordView")
	public ModelAndView newTrainee(@ModelAttribute("t") @Valid Trainee t, BindingResult result) {
		ModelAndView mv = new ModelAndView();
	
		ArrayList<String> al=new ArrayList<>();
		al.add("India");
		al.add("England");
		al.add("Australia");
		al.add("Canada");
		mv.addObject("list",al);
		mv.setViewName("Hello");
		
		String name = traineeService.addTrainee(t, result);
		
		if (result.hasErrors()) {
			mv.setViewName("addRecordForm");
			return mv;
		}
		mv.addObject("key", t);
		mv.setViewName("authenticate");
		return mv;

	}

//	
//	// GET ALL
//	@RequestMapping(method = RequestMethod.GET, path = "/getAll")
//	public ModelAndView getAllTranee(Trainee trainee, Model model) {
//		ModelAndView mv = new ModelAndView();
//		List<Trainee> list = traineeService.getAllTrainee();
//		model.addAttribute("Trainee", trainee);
//
//		mv.addObject("tlist", list);
//		mv.addObject("trainee", new Trainee());
//		// mv.addObject("key", list);
//		mv.setViewName("traineeInfo");
//		return mv;
//	}
//	
//	@Transactional
//	@RequestMapping(method = RequestMethod.GET, path = "/ref/{id}")
//	public ModelAndView searchEmployeeNew(@PathVariable("id")int id) {
//
//		ModelAndView mv = new ModelAndView();
//
//		Trainee success = traineeService.searchTrainee(id);
//		List<Trainee> list = new ArrayList<Trainee>();
//		list.add(success);
//		mv.addObject("id", success.getTraineeId());
//		mv.addObject("name", success.getTraineeName());
//		mv.addObject("location", success.getTraineeLocation());
//		mv.addObject("domain", success.getTraineeDomain());
//		mv.setViewName("retrievedByLink");
//		return mv;
//	}
}
