package com.cg.exception;

import java.sql.SQLException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class HandleException {
	
	@ExceptionHandler(SQLException.class)
	public void handleException(HttpServletResponse res) {
		
		try {
			res.sendRedirect("/login/getPage");
		} catch (Exception e) {
			
			e.printStackTrace();
		}
	}

}
