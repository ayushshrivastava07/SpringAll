package com.cg.ftf.dao;

import com.cg.ftf.entities.Query;
import com.cg.ftf.entities.Query2;

public interface QueryDao 
{
	Query fetchQuery(int queryId);
	
	Query2 fetchQuery1(int queryId);
}
