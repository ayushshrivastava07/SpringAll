package com.cg.MongoTemplate.dao;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="mongotemplate")
public class Employee {
int id;
String name;
String phoneNo;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getPhoneNo() {
	return phoneNo;
}
public void setPhoneNo(String phoneNo) {
	this.phoneNo = phoneNo;
}


}
