package com.cg.MongoTemplate.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.MongoTemplate.dao.DaoClass;
import com.cg.MongoTemplate.dao.Employee;
import com.cg.MongoTemplate.exception.EmployeeNotFoundException;
import com.cg.MongoTemplate.exception.NotFoundException;

@Service
public class ServiceClass {
	@Autowired
	DaoClass daoObject;

	public void insertData(Employee emp) {
		daoObject.insertData(emp);
	}

	public Employee readData(int id) throws EmployeeNotFoundException {
		Employee e = daoObject.readData(id);
		if (e == null) {
			throw new EmployeeNotFoundException();
		}
		return e;
	}
	
	//Get All
	public List<Employee> getAllEmployee() throws NotFoundException {
	
		List<Employee> list= daoObject.findAll();
		if(list.size()==0)
			throw new NotFoundException();
		
		return list;
			
	}

	//Update
	public void update(Employee emp) {
		// TODO Auto-generated method stub
	     daoObject.save(emp);
		
	}

	//Delete
	public void delete(int id) {
		// TODO Auto-generated method stub
		daoObject.delete(id);
	}
}
