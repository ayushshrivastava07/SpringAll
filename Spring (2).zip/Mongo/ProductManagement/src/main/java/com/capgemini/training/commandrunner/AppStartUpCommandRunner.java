//package com.capgemini.training.commandrunner;
//
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.CommandLineRunner;
//import org.springframework.stereotype.Component;
//
//import com.capgemini.training.customer.entity.Product;
//import com.capgemini.training.repository.ProductRepository;
//import com.capgemini.training.service.ProductService;
//
//@Component
//public class AppStartUpCommandRunner implements CommandLineRunner {
//
//	@Autowired
//	ProductService service;
//
//	@Override
//	public void run(String... args) throws Exception {
//		Product p1 = new Product();
//		p1.setpId(1000);
//		p1.setProductName("DEMOPRODUCT1");
//		p1.setProductPrice(50000);
//		p1.setProductType("DEMOTYPE");
//
//		Product p2 = new Product();
//		p2.setpId(1001);
//		p2.setProductName("DEMOPRODUCT2");
//		p2.setProductPrice(60000);
//		p2.setProductType("DEMOTYPE");
//
//		service.save(p1);
//		service.save(p2);
////		p1	List<Product> customers = rep.getAllCustomer();
//		List<Product> products = service.getAllProduct();
//		for (Product product : products) {
//			System.out.println(product.getProductName());
//		}
//
//	}
//
//}
