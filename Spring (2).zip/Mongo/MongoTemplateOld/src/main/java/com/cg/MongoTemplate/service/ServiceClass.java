package com.cg.MongoTemplate.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.MongoTemplate.dao.DaoClass;
import com.cg.MongoTemplate.dao.Employee;
import com.cg.MongoTemplate.exception.EmployeeNotFoundException;

@Service
public class ServiceClass {
	@Autowired
	DaoClass daoObject;

	public void insertData(Employee emp) {
		daoObject.insertData(emp);
	}

	public Employee readData(int id) throws EmployeeNotFoundException {
		Employee e = daoObject.readData(id);
		if (e == null) {
			throw new EmployeeNotFoundException("NOT FOUND");
		}
		return e;
	}
}
