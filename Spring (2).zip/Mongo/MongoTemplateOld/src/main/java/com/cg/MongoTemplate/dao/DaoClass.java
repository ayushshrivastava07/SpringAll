package com.cg.MongoTemplate.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Transactional
@Repository
public class DaoClass {
	@Autowired
	MongoTemplate mongoTemplate;

	public void insertData(Employee emp) {
		mongoTemplate.save(emp);
	}

	public Employee readData(int id) {
		Employee e = mongoTemplate.findById(id, Employee.class);
		return e;
	}




}
