package my;

import org.springframework.validation.BindingResult;

public interface AccountService {
	
	public String newRecord(Employee e, BindingResult result);
	public Employee readTable(int id);
	public Employee updateTable(int id, String name);
	public int deleteTable(int id);

}
