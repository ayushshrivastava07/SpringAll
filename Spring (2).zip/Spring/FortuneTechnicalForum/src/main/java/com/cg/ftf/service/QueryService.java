package com.cg.ftf.service;

import com.cg.ftf.entities.Query;
import com.cg.ftf.entities.Query2;

public interface QueryService 
{
	Query fetchQuery(int queryId);
	
	Query2 fetchQuery1(int queryId);
}
