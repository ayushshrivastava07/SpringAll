package com.capgemini.training.service;

import java.util.ArrayList;
import java.util.List;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.capgemini.training.customer.entity.Product;
import com.capgemini.training.repository.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductRepository rep;

	// Create
	@Transactional
	public void save(Product prod) {
		rep.save(prod);
	}

	// Get
	@Override
	public Product getProduct(int pId) {
		return rep.findById(pId).get();
	}

	// Get All
	public List<Product> getAllProduct() {
		List<Product> product = new ArrayList<>();
		for (Product prod : rep.findAll()) {
			product.add(prod);
		}
		return product;
	}

	// Update
	@Transactional
	public void update(Product prod) {
		rep.save(prod);
	}

	// Delete
	@Transactional
	public void delete(int pId) {
		rep.deleteById(pId);
	}

}
