package com.capgemini.training.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.capgemini.training.customer.entity.Product;
import com.capgemini.training.service.ProductService;

@RestController
@RequestMapping("/api")
public class ProductController {
	@Autowired
	ProductService service;

	public ProductController() {
		System.out.println("CONTROLLER OBJ");
	}

	// Save
	@PostMapping("/products")
	public String createProduct(@RequestBody Product prod) {
		service.save(prod);
		return "Successfully Added Product";
	}

	// Get Product
	@GetMapping("/products/{pId}")
	public Product getProduct(@PathVariable int pId) {
		return service.getProduct(pId);
	}

	// Get all Product
	@GetMapping("/products")
	public List<Product> getAllProduct() {
		return service.getAllProduct();
	}

	// Update Product
	@PutMapping("/products")
	public String updateProduct(@RequestBody Product prod) {
		service.update(prod);
		return "Successfully Updated Product";
	}

	// Delete Product
	@DeleteMapping("/product/{pId}")
	public String deleteProduct(@PathVariable int pId) {
		service.delete(pId);
		return "Successfully Deleted Product " + pId;
	}

}
