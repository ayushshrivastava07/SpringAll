package com.cg.MongoTemplate.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

@ControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(value = { EmployeeNotFoundException.class })
	@ResponseStatus(code = HttpStatus.BAD_REQUEST, reason = "Not Found In Database")
	protected void handleConflict() {
		System.out.println("My handler");
	}
	
	@ExceptionHandler(value = { NotFoundException.class })
	@ResponseStatus(code = HttpStatus.BAD_REQUEST, reason = "Empty Database")
	protected void handle() {
		System.out.println("My handler");
	}
}
