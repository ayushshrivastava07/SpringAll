package com.cg.MongoTemplate.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Transactional
@Repository
public class DaoClass {
	@Autowired
	MongoTemplate mongoTemplate;

	public void insertData(Employee emp) {
		mongoTemplate.save(emp);
	}

	public Employee readData(int id) {
		Employee e = mongoTemplate.findById(id, Employee.class);
		return e;
	}

	public List<Employee> findAll() {
		List<Employee> e = mongoTemplate.findAll( Employee.class);
		// TODO Auto-generated method stub
		return e;
	}


	public void save(Employee emp) {
		// TODO Auto-generated method stub
		mongoTemplate.save(emp);
	}

	public void delete(int id) {
		// TODO Auto-generated method stub
		Employee e=mongoTemplate.findById(id, Employee.class);
		System.out.println(e.getName());
		mongoTemplate.remove(e);
	
	

	}

	
}
