package com.cg.MongoTemplate;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import com.cg.MongoTemplate.dao.Employee;
import com.cg.MongoTemplate.exception.EmployeeNotFoundException;
import com.cg.MongoTemplate.exception.NotFoundException;
import com.cg.MongoTemplate.service.ServiceClass;

@RestController
public class Controller {
	@Autowired
	ServiceClass service;

	@PostMapping(path = "/insert")
	public String insertData(@RequestBody Employee emp) {
		service.insertData(emp);
		return "Success";
	}
   
	//ReadById
	@GetMapping(path = "/read/{id}")
	public Employee insertData(@PathVariable int id) throws EmployeeNotFoundException {
		Employee e = service.readData(id);
		System.out.println(e);
		return e;
	}
	
	//GetAll
	@GetMapping("/read")
	public List<Employee> getAllEmployee() throws NotFoundException  {
		return service.getAllEmployee();
	}
	
	//Update
	@PutMapping("/update")
	public String updateProduct(@RequestBody Employee emp) {
		service.update(emp);
		return "Successfully Updated Product";
	}
	
	//Delete
	@DeleteMapping("/delete/{id}")
	public String deleteEmployee(@PathVariable int id) {
		service.delete(id);
		return "Successfully Deleted Product " + id;
	}

}
