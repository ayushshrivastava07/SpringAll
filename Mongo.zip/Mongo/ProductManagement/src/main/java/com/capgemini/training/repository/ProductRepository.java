package com.capgemini.training.repository;


import org.springframework.data.mongodb.repository.MongoRepository;

import com.capgemini.training.customer.entity.Product;

public interface ProductRepository extends MongoRepository<Product, Integer> {

}
