package com.capgemini.training.service;

import java.util.List;

import com.capgemini.training.customer.entity.Product;

public interface ProductService {

	// Create
	public void save(Product prod);

	// Get one
	public Product getProduct(int pId);

	// Get All
	public List<Product> getAllProduct();

	// Update
	public void update(Product prod);

	// Delete
	public void delete(int pId);

}
