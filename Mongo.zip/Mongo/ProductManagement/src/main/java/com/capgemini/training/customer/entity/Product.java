package com.capgemini.training.customer.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@Document(collection="newCollect")
public class Product {
	public Product() {
		System.out.println("ENTITY OBJECT");
	}

	@Id
	private int pId;

	private String productName;

	private int productPrice;

	private String productType;

	@Override
	public String toString() {
		return "Product [pId=" + pId + ", productName=" + productName + ", productPrice=" + productPrice
				+ ", productType=" + productType + "]";
	}

	// GETTERS AND SETTERS FOR ECLASS
	public int getpId() {
		return pId;
	}

	public void setpId(int pId) {
		this.pId = pId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

}
