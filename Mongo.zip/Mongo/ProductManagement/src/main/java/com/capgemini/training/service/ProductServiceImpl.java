package com.capgemini.training.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.training.customer.entity.Product;
import com.capgemini.training.repository.ProductRepository;

@Service
@Transactional
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductRepository rep;
public ProductServiceImpl() {
	System.out.println("SERVICE IMPL");
}
	// Create

	public void save(Product prod) {
		rep.save(prod);
	}

	// Get
	@Override
	public Product getProduct(int pId) {
		return rep.findById(pId).get();
	}

	// Get All
	public List<Product> getAllProduct() {
		List<Product> product = new ArrayList<>();
		for (Product prod : rep.findAll()) {
			product.add(prod);
		}
		return product;
	}

	// Update
	public void update(Product prod) {
		rep.save(prod);
	}

	// Delete
	public void delete(int pId) {
		rep.deleteById(pId);
	}

}
