package my;

import javax.persistence.EntityManager;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LoginController {
	@Autowired
	AccountServiceImpl impl;
	EntityManager em;

	@RequestMapping(method=RequestMethod.GET, path="/page")
	public String sayHello(@ModelAttribute("e") Employee e) {
		
		return "Hello";
	}
	
	@RequestMapping(method=RequestMethod.POST, path="/getrecord")
	public ModelAndView newEmployee(@ModelAttribute("e") @Valid Employee e,BindingResult result) {
		
		
		ModelAndView mv = new ModelAndView();
		mv.setViewName("Hello");
		String name=impl.newRecord(e, result);
		if(result.hasErrors())
		{
			return mv;
		}
		mv.setViewName("record");
		return mv;
	}

    @Transactional
    @RequestMapping(method=RequestMethod.GET, path="/read/{id}")
    public ModelAndView readEmployee(@PathVariable("id")int id) {
        
        Employee e = impl.readTable(id);
        ModelAndView mv = new ModelAndView();
        mv.setViewName("record");
        mv.addObject("key", e);
        System.out.println(e.getAge() + "      " + e.getName());
        return mv;
    }
    
    
    @Transactional
    @RequestMapping(method=RequestMethod.GET, path="/update/{id}/{name}")
    public ModelAndView updateEmployee(@PathVariable("id")int id,@PathVariable("name") String name) {
        
        Employee e = impl.updateTable(id, name);
        ModelAndView mv = new ModelAndView();
        mv.setViewName("update");
        mv.addObject("key", e);
        e.setName(name);
//        em.persist(e);
        return mv;
    }
    
    @Transactional
    @RequestMapping(method=RequestMethod.GET, path="/delete/{id}")
    public ModelAndView deleteEmployee(@PathVariable("id")int id) {
        
        int eid = impl.deleteTable(id);
        ModelAndView mv = new ModelAndView();
        mv.setViewName("delete");
        mv.addObject("key", eid);
        
        return mv;
   }


}
