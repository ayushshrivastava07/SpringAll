package com.cg.ftf.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.ftf.entities.Query;
import com.cg.ftf.entities.Query2;
import com.cg.ftf.service.QueryService;



@Controller
public class ForumController 
{
	@Autowired
	QueryService qSer;
	
	@RequestMapping(path="/getPage",method=RequestMethod.GET)
	 public String sayHello( )
	 {
		 return "Home";
		 }

	
	@RequestMapping(path="/search",method=RequestMethod.POST)
	public String searchQuery(@RequestParam("queryId")Integer queryId, Model model)
	{		
		Query qdetail = qSer.fetchQuery(queryId);
		if(qdetail!=null)
		{
			model.addAttribute("qdetails",qdetail);
			return "result";
		}else
			
			model.addAttribute("queryId",queryId);
		System.out.println("Print Dipesh:");
			return "notFound";
		
	}
	

	@RequestMapping(path="/search2",method=RequestMethod.POST)
	public String searchQuery2(@RequestParam("queryId")Integer queryId, Model model)
	{		
		Query2 qdetail = qSer.fetchQuery1(queryId);
		if(qdetail!=null)
		{
			model.addAttribute("qdetails",qdetail);
			return "result";
		}else
			
			model.addAttribute("queryId",queryId);
		System.out.println("Print Dipesh:");
			return "notFound";
		
	}
}
